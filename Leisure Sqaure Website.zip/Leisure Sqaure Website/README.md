# Responsive Leisure Square Website
## Reference [Watch it on youtube](https://youtu.be/HW1zt2EPMqY)
### Responsive Leisure Square Website

- Responsive Leisure Square Restaurant Website Design Using HTML CSS & JavaScript
- Includes a dark and light mode.
- Smooth scrolling in each section.
- Contains animations when scrolling.
- Developed first with the Mobile First methodology, then for desktop.
- Compatible with all mobile devices and with a beautiful and pleasant user interface.

Un zip the file and move it to 'htdocs' folder present in 'xampp' main folder
create 'ortrs_db' file in php My Admin
import ortrs_db.sql.

type: ' localhost/Leisure Sqaure Website/ '   to run the project.